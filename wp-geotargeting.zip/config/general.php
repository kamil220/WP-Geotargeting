<?php

define( 'GEOTARGET_PLUGIN_PATH', plugin_dir_path( __DIR__ ) );
define( 'GEOTARGET_PLUGIN_URL', plugin_dir_url( __DIR__ ) );
