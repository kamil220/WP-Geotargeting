# WP Geotargeting

The plugin's purpose is to display appropriate content for users from specific countries, e.g., change the default homepage or hide the career tab.

### Work with cache
We created this plugin because some already created
resources don't work with cache plugins, which is a big problem.

Our solution uses an unconventional method that works with cache plugins.
